# Chess Times Android wrapper

This Android Studio project wraps the supplied Chess Times HTML in a local Android WebView. The HTML source is copied unchanged to `app/src/main/assets/index.html`. The uploaded chess logo is bundled as `app/src/main/assets/chess-times-logo.png` and used as the Android launcher icon (`app/src/main/res/drawable/app_logo.png`). JavaScript and DOM storage are enabled so the existing client-side chess logic and localStorage profile/session data can run on-device.

## Build the APK

1. Open this folder in Android Studio (Giraffe or newer).
2. Install Android SDK Platform 35 and accept the Android Gradle Plugin setup prompts.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will create the APK under `app/build/outputs/apk/debug/app-debug.apk`.

## Offline note

The HTML file itself is preserved unchanged, but it references Tailwind CSS, Font Awesome, and Google Fonts from public CDNs. Those three assets are therefore fetched from the internet by the original page and are not bundled locally in this wrapper. Core JavaScript/chess logic and localStorage are local, but the full original styling/icon/font appearance is not guaranteed offline until those CDN assets are vendored into the project. Online matchmaking or any remote services also require a backend/internet; this HTML currently implements its visible pairing flow locally rather than connecting to a real matchmaking server.
